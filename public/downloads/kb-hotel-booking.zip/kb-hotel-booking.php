<?php
/**
 * Plugin Name: KB Hotel Booking
 * Plugin URI: https://bookingkub.com
 * Description: A customizable booking search widget that redirects to your main booking engine.
 * Version: 1.0.1
 * Author: BookingKub
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define Plugin Constants
define('HBW_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('HBW_PLUGIN_URL', plugin_dir_url(__FILE__));

// 1. Admin Settings Page (To set the Target URL)
add_action('admin_menu', 'hbw_add_admin_menu');
add_action('admin_init', 'hbw_settings_init');

function hbw_add_admin_menu()
{
    add_options_page('Hotel Booking Widget', 'Booking Widget', 'manage_options', 'hotel_booking_widget', 'hbw_options_page');
}

function hbw_settings_init()
{
    register_setting('hbwPlugin', 'hbw_settings');
    add_settings_section('hbw_plugin_page_section', 'General Settings', 'hbw_settings_section_callback', 'hotel_booking_widget');
    add_settings_field('hbw_target_url', 'Booking Engine URL', 'hbw_target_url_render', 'hotel_booking_widget', 'hbw_plugin_page_section');
    add_settings_field('hbw_hotel_id', 'Hotel ID', 'hbw_hotel_id_render', 'hotel_booking_widget', 'hbw_plugin_page_section');
    add_settings_field('hbw_layout', 'Widget Layout', 'hbw_layout_render', 'hotel_booking_widget', 'hbw_plugin_page_section');
    add_settings_field('hbw_primary_color', 'Primary Color', 'hbw_primary_color_render', 'hotel_booking_widget', 'hbw_plugin_page_section');
}

function hbw_settings_section_callback()
{
    echo 'Configure where the search form should redirect users.';
}

function hbw_target_url_render()
{
    $options = get_option('hbw_settings');
    ?>
    <input type='text' name='hbw_settings[hbw_target_url]'
        value='<?php echo isset($options['hbw_target_url']) ? esc_attr($options['hbw_target_url']) : ''; ?>'
        style="width: 400px;" placeholder="https://app.bookingkub.com">
    <p class="description">Enter the full URL of your booking app (without /search).</p>
    <?php
}

function hbw_hotel_id_render()
{
    $options = get_option('hbw_settings');
    ?>
    <input type='text' name='hbw_settings[hbw_hotel_id]'
        value='<?php echo isset($options['hbw_hotel_id']) ? esc_attr($options['hbw_hotel_id']) : ''; ?>'
        style="width: 400px;" placeholder="e.g., cm-resort">
    <p class="description">
        Found in your BookingKub Dashboard URL (e.g., app.bookingkub.com/hotel/<strong>YOUR_ID</strong>).<br>
        If set, you don't need to add it to the shortcode.
    </p>
    <?php
}

function hbw_layout_render()
{
    $options = get_option('hbw_settings');
    $layout = isset($options['hbw_layout']) ? $options['hbw_layout'] : 'horizontal';
    ?>
    <select name='hbw_settings[hbw_layout]' id="hbw-layout-input">
        <option value='horizontal' <?php selected($layout, 'horizontal'); ?>>Horizontal (Default)</option>
        <option value='vertical' <?php selected($layout, 'vertical'); ?>>Vertical (Sidebar)</option>
        <option value='box' <?php selected($layout, 'box'); ?>>Box (Card)</option>
    </select>
    <p class="description">Choose how the widget should be displayed.</p>
    <?php
}

function hbw_primary_color_render()
{
    $options = get_option('hbw_settings');
    $color = isset($options['hbw_primary_color']) ? $options['hbw_primary_color'] : '#10b981';
    ?>
    <div style="display: flex; align-items: center; gap: 10px;">
        <input type='color' name='hbw_settings[hbw_primary_color]' id="hbw-color-input"
            value='<?php echo esc_attr($color); ?>'
            style="height: 40px; width: 60px; padding: 0; border: none; cursor: pointer;">
        <input type="text" id="hbw-color-text" value="<?php echo esc_attr($color); ?>"
            style="width: 100px; text-transform: uppercase;" readonly>
    </div>
    <?php
}

function hbw_options_page()
{
    $options = get_option('hbw_settings');
    $hotel_id = isset($options['hbw_hotel_id']) ? $options['hbw_hotel_id'] : 'YOUR_HOTEL_ID';
    $shortcode_display = '[hotel_booking_search' . ($hotel_id !== 'YOUR_HOTEL_ID' && !empty($hotel_id) ? '' : ' hotel_id="' . $hotel_id . '"') . ']';

    // Default values for preview
    $preview_color = isset($options['hbw_primary_color']) ? $options['hbw_primary_color'] : '#10b981';
    $preview_layout = isset($options['hbw_layout']) ? $options['hbw_layout'] : 'horizontal';
    ?>
    <!-- Import Outfit Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Flatpickr (Guaranteed load in Admin) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

    <style>
        :root {
            --hbw-primary: #10b981;
            --hbw-bg: #f8fafc;
            --hbw-card-bg: #ffffff;
            --hbw-text-main: #0f172a;
            --hbw-text-muted: #64748b;
            --hbw-border: #e2e8f0;
        }

        .hbw-admin-wrap {
            font-family: 'Outfit', sans-serif;
            max-width: 1200px;
            margin: 20px auto;
            color: var(--hbw-text-main);
            box-sizing: border-box;
        }

        .hbw-admin-wrap * {
            box-sizing: border-box;
        }

        /* Header */
        .hbw-header {
            text-align: center;
            margin-bottom: 30px;
            padding: 30px 0;
            background: radial-gradient(circle at center, rgba(16, 185, 129, 0.08) 0%, rgba(255, 255, 255, 0) 70%);
        }

        .hbw-header h1 {
            font-size: 2.2rem;
            font-weight: 800;
            color: #0f172a;
            margin: 0;
            letter-spacing: -0.025em;
        }

        .hbw-header h1 span {
            color: var(--hbw-primary);
        }

        .hbw-header p {
            font-size: 1rem;
            color: var(--hbw-text-muted);
            margin-top: 8px;
        }

        /* Layout Stacked */
        .hbw-grid {
            display: flex;
            flex-direction: column;
            gap: 15px;
            /* Reduced gap */
        }

        .hbw-settings-row {
            display: grid;
            grid-template-columns: 1fr;
            gap: 15px;
            /* Reduced gap */
        }

        @media (min-width: 900px) {
            .hbw-settings-row {
                grid-template-columns: 2fr 1fr;
            }
        }

        /* Cards */
        .hbw-card {
            background: var(--hbw-card-bg);
            border-radius: 12px;
            /* Slightly smaller radius */
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
            padding: 20px;
            /* Reduced padding */
            border: 1px solid var(--hbw-border);
        }

        .hbw-card h2 {
            font-size: 1.1rem;
            font-weight: 700;
            margin-top: 0;
            margin-bottom: 12px;
            /* Reduced margin */
            padding-bottom: 10px;
            /* Reduced padding */
            border-bottom: 1px solid var(--hbw-border);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* Form Styling - Compact */
        .hbw-admin-wrap .form-table th {
            width: 180px;
            font-weight: 600;
            color: var(--hbw-text-main);
            padding: 10px 0;
            /* Reduced padding */
            font-size: 0.95rem;
        }

        .hbw-admin-wrap .form-table td {
            padding: 8px 0;
            /* Reduced padding */
        }

        .hbw-admin-wrap input[type="text"],
        .hbw-admin-wrap input[type="url"],
        .hbw-admin-wrap select {
            width: 100%;
            padding: 8px 12px;
            border-radius: 8px;
            border: 1px solid var(--hbw-border);
            font-family: 'Outfit', sans-serif;
            font-size: 0.9rem;
            transition: all 0.2s;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        }

        .hbw-admin-wrap input[type="text"]:focus,
        .hbw-admin-wrap input[type="url"]:focus,
        .hbw-admin-wrap select:focus {
            border-color: var(--hbw-primary);
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.15);
            outline: none;
        }

        .hbw-description {
            font-size: 0.8rem;
            color: var(--hbw-text-muted);
            margin-top: 4px;
        }

        /* Hide default section title if it exists */
        .hbw-admin-wrap h2:not(.hbw-card-title) {
            display: none;
        }

        /* Custom Card Title class to ensure visibility */
        .hbw-card-title {
            display: flex !important;
        }

        /* Button */
        .hbw-admin-wrap .button-primary {
            background-color: #0f172a !important;
            border-color: #0f172a !important;
            color: #fff !important;
            padding: 8px 25px !important;
            border-radius: 6px !important;
            font-weight: 600 !important;
            font-size: 0.95rem !important;
            height: auto !important;
            transition: all 0.2s !important;
            box-shadow: 0 4px 6px -1px rgba(15, 23, 42, 0.2) !important;
            margin-top: 10px !important;
        }

        .hbw-admin-wrap .button-primary:hover {
            background-color: #334155 !important;
            transform: translateY(-1px);
        }

        /* Preview Area */
        .hbw-preview-area {
            position: sticky;
            top: 20px;
            background: #f8fafc;
            /* Default Light */
            border: 2px dashed #cbd5e1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 350px;
            overflow: hidden;
            transition: background 0.3s ease;
        }

        /* Preview Background States */
        .hbw-bg-light {
            background: #f8fafc;
        }

        .hbw-bg-dark {
            background: #0f172a;
            border-color: #334155;
        }

        .hbw-bg-image {
            background: url('https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80') center/cover no-repeat;
            position: relative;
        }

        .hbw-bg-image::before {
            content: '';
            position: absolute;
            inset: 0;
            background: rgba(0, 0, 0, 0.3);
            z-index: 0;
        }

        /* Preview Area - Full Width Design */
        .hbw-preview-section {
            margin-top: 10px;
        }

        .hbw-preview-section .hbw-card-title {
            margin-bottom: 0;
            border-bottom: none;
            border-radius: 16px 16px 0 0;
            background: #fff;
            padding: 20px 25px;
        }

        .hbw-preview-area {
            background: #f8fafc;
            /* Default Light */
            border: 1px solid var(--hbw-border);
            border-top: none;
            border-radius: 0 0 16px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 400px;
            /* Taller for full width */
            overflow: hidden;
            transition: background 0.3s ease;
            position: relative;
        }

        .hbw-bg-light {
            background: #f8fafc;
        }

        .hbw-bg-dark {
            background: #0f172a;
        }

        .hbw-bg-image {
            background: url('https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80') center/cover no-repeat;
            position: relative;
        }

        .hbw-bg-image::before {
            content: '';
            position: absolute;
            inset: 0;
            background: rgba(0, 0, 0, 0.4);
            z-index: 0;
        }

        /* Toggle Controls */
        .hbw-preview-controls {
            position: absolute;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
            padding: 6px;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(4px);
            border-radius: 99px;
            border: 1px solid #e2e8f0;
            z-index: 10;
        }

        .hbw-bg-toggle {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            border: 2px solid transparent;
            cursor: pointer;
            transition: all 0.2s;
        }

        .hbw-bg-toggle:hover {
            transform: scale(1.1);
        }

        .hbw-bg-toggle.active {
            border-color: var(--hbw-primary);
            box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.2);
        }

        .bg-btn-light {
            background: #f1f5f9;
        }

        .bg-btn-dark {
            background: #0f172a;
        }

        .bg-btn-image {
            background: linear-gradient(45deg, #FF9A9E 0%, #FECFEF 99%, #FECFEF 100%);
        }

        #hbw-preview-wrapper {
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px 20px;
            transform-origin: center center;
            transition: transform 0.3s ease;
            z-index: 1;
            /* Above image overlay */
        }

        #hbw-preview-container {
            width: 100%;
            display: flex;
            justify-content: center;
        }

        .hbw-preview-form {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.8);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15), 0 0 0 1px rgba(0, 0, 0, 0.02);
            padding: 24px;
            display: flex;
            gap: 15px;
            font-family: 'Outfit', sans-serif;
            box-sizing: border-box;
        }

        /* Preview Layouts */
        .hbw-layout-horizontal .hbw-preview-form {
            flex-direction: row;
            align-items: center;
            border-radius: 100px;
            width: 100%;
            max-width: 1000px;
            min-width: 600px;
            padding-left: 30px;
            padding-right: 30px;
        }

        .hbw-layout-vertical .hbw-preview-form {
            flex-direction: column;
            border-radius: 24px;
            width: 350px;
        }

        .hbw-layout-box .hbw-preview-form {
            flex-direction: column;
            border-radius: 24px;
            width: 320px;
            box-shadow: none;
            border: 1px solid var(--hbw-border);
        }

        /* Updated Preview Styles */
        .hbw-p-field {
            background: #f1f5f9;
            border-radius: 50px;
            padding: 8px 16px 8px 48px;
            /* Space for icon */
            flex: 1;
            min-width: 130px;
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: center;
            height: 56px;
            /* Taller like live */
        }

        .hbw-layout-vertical .hbw-p-field,
        .hbw-layout-box .hbw-p-field {
            width: 100%;
            padding-left: 56px;
        }

        .hbw-p-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--hbw-preview-primary);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .hbw-p-label {
            font-size: 0.65rem;
            text-transform: uppercase;
            font-weight: 800;
            color: var(--hbw-text-muted);
            margin-bottom: 2px;
            line-height: 1;
            letter-spacing: 0.05em;
        }

        .hbw-p-value {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--hbw-text-main);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .hbw-p-btn {
            background: var(--hbw-preview-primary);
            color: white;
            border: none;
            border-radius: 50px;
            padding: 0 40px;
            /* Wider like live pill */
            font-weight: 700;
            cursor: default;
            white-space: nowrap;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            height: 56px;
            /* Match field height */
            font-size: 1rem;
            transition: all 0.3s;
        }

        .hbw-layout-vertical .hbw-p-btn,
        .hbw-layout-box .hbw-p-btn {
            width: 100%;
        }

        /* Quick Start Code */
        .hbw-code-block {
            background: #1e293b;
            color: #e2e8f0;
            padding: 12px;
            border-radius: 8px;
            font-family: monospace;
            display: flex;
            justify-content: space-between;
            align-items: center;
            overflow-x: auto;
            font-size: 0.85rem;
        }
    </style>

    <div class="hbw-admin-wrap">
        <div class="hbw-header">
            <h1>Hotel Booking <span>Widget</span></h1>
            <p>Connect your WordPress site to your booking engine in seconds.</p>
        </div>

        <div class="hbw-grid">
            <!-- Settings Row (Top) -->
            <div class="hbw-settings-row">
                <div class="hbw-card" style="margin-bottom: 0;">
                    <h2 class="hbw-card-title">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="3"></circle>
                            <path
                                d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z">
                            </path>
                        </svg>
                        Configuration
                    </h2>
                    <form action='options.php' method='post'>
                        <?php
                        settings_fields('hbwPlugin');
                        do_settings_sections('hotel_booking_widget');
                        submit_button('Save Settings');
                        ?>
                    </form>
                </div>

                <div class="hbw-card" style="margin-bottom: 0;">
                    <h2 class="hbw-card-title">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path
                                d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z" />
                            <path d="M5 3v4M3 5h4" />
                        </svg>
                        Quick Start Guide
                    </h2>
                    <p style="margin-bottom: 8px; font-weight: 600; color: #0f172a;">Shortcode</p>
                    <p class="hbw-description" style="margin-bottom: 16px;">Copy and paste this code into any page or post
                        to display your booking widget.</p>
                    <div class="hbw-code-block">
                        <code><?php echo $shortcode_display; ?></code>
                    </div>
                </div>
            </div>

            <!-- Preview Section (Bottom Full Width) -->
            <div class="hbw-preview-section">
                <h2 class="hbw-card-title"
                    style="background:var(--hbw-card-bg); border: 1px solid var(--hbw-border); border-bottom: none; border-radius: 12px 12px 0 0; padding: 15px 20px; margin: 0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02)">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
                        <circle cx="12" cy="12" r="3" />
                    </svg>
                    Live Preview
                </h2>
                <div class="hbw-preview-area hbw-bg-light" style="border-radius: 0 0 12px 12px;">
                    <div class="hbw-preview-controls">
                        <div class="hbw-bg-toggle bg-btn-light active" onclick="setPreviewBg('light')" title="Light Mode">
                        </div>
                        <div class="hbw-bg-toggle bg-btn-dark" onclick="setPreviewBg('dark')" title="Dark Mode"></div>
                        <div class="hbw-bg-toggle bg-btn-image" onclick="setPreviewBg('image')" title="Image Background">
                        </div>
                    </div>

                    <!-- Wrapper for Scaling -->
                    <div id="hbw-preview-wrapper">
                        <div id="hbw-preview-container">
                            <?php 
                            // Render actual widget inside preview, disabling form submission
                            echo hbw_render_search_widget(array('is_preview' => true)); 
                            ?>
                        </div>
                    </div>

                    <p style="margin-top: 20px; color: #94a3b8; font-size: 0.8rem; z-index: 1;">
                        Live Preview (Interactive)
                    </p>
                </div>
            </div>
        </div>

        <script>
            // Global for onclick access
            function setPreviewBg(mode) {
                const area = document.querySelector('.hbw-preview-area');
                const toggles = document.querySelectorAll('.hbw-bg-toggle');

                if (!area) return;
                // Reset classes
                area.classList.remove('hbw-bg-light', 'hbw-bg-dark', 'hbw-bg-image');
                area.classList.add('hbw-bg-' + mode);

                // Update active toggle
                toggles.forEach(t => t.classList.remove('active'));
                const activeToggle = document.querySelector('.bg-btn-' + mode);
                if (activeToggle) activeToggle.classList.add('active');
            }

            document.addEventListener('DOMContentLoaded', function () {
                const layoutInput = document.getElementById('hbw-layout-input');
                const colorInput = document.getElementById('hbw-color-input');
                const colorText = document.getElementById('hbw-color-text');
                const previewContainer = document.getElementById('hbw-preview-container');
                const previewWrapper = document.getElementById('hbw-preview-wrapper');
                
                function updatePreviewScale() {
                    if (!previewWrapper || !previewContainer) return;
                    
                    const pForm = previewContainer.querySelector('.hbw-form');
                    const pArea = document.querySelector('.hbw-preview-area');
                    
                    if (!pForm || !pArea) return;

                    const availableWidth = pArea.offsetWidth - 40;
                    const requiredWidth = pForm.scrollWidth + 20; 

                    if (requiredWidth > availableWidth) {
                        const scale = availableWidth / requiredWidth;
                        previewWrapper.style.transform = `scale(${scale})`;
                    } else {
                        previewWrapper.style.transform = 'scale(1)';
                    }
                }

                window.addEventListener('resize', updatePreviewScale);
                setTimeout(updatePreviewScale, 100);
                setTimeout(updatePreviewScale, 500); 

                // Update Layout
                if (layoutInput) {
                    layoutInput.addEventListener('change', function (e) {
                        const aWrapper = document.getElementById('hbw-preview-container').querySelector('.hbw-wrapper');
                        if (aWrapper) {
                            aWrapper.className = aWrapper.className.replace(/hbw-layout-\w+/g, '');
                            aWrapper.classList.add('hbw-layout-' + e.target.value);
                            setTimeout(updatePreviewScale, 50);
                        }
                    });
                }

                // Update Color
                if (colorInput) {
                    colorInput.addEventListener('input', function (e) {
                        const color = e.target.value;
                        const aWrapper = document.getElementById('hbw-preview-container').querySelector('.hbw-wrapper');
                        if (aWrapper) {
                            aWrapper.style.setProperty('--hbw-widget-primary', color);
                        }
                        if (colorText) colorText.value = color;
                    });
                }

                if (colorText && colorInput) {
                    colorText.addEventListener('change', function (e) {
                        const color = e.target.value;
                        colorInput.value = color;
                        const aWrapper = document.getElementById('hbw-preview-container').querySelector('.hbw-wrapper');
                        if (aWrapper) {
                            aWrapper.style.setProperty('--hbw-widget-primary', color);
                        }
                    });
                }
            });
        </script>
        <?php
}

// 2. Register Shortcode [hotel_booking_search]
// 2. Register Shortcode [hotel_booking_search]
// 2. Register Shortcode [hotel_booking_search]
function hbw_render_search_widget($atts)
{
    // Context: is_preview
    $is_preview = isset($atts['is_preview']) ? $atts['is_preview'] : false;

    // Get target URL from settings
    $options = get_option('hbw_settings');
    $target_url = isset($options['hbw_target_url']) ? trim($options['hbw_target_url'], '/') : '';
    $default_hotel_id = isset($options['hbw_hotel_id']) ? $options['hbw_hotel_id'] : '';
    $layout = isset($options['hbw_layout']) ? $options['hbw_layout'] : 'horizontal';

    // Auto-fallback
    if (empty($target_url)) {
        $target_url = 'https://app.bookingkub.com';
    }

    $primary_color = isset($options['hbw_primary_color']) ? $options['hbw_primary_color'] : '#10b981';

    // Enqueue Styles
    wp_enqueue_style('hbw-style', HBW_PLUGIN_URL . 'assets/style.css', array(), '1.1.0');
    wp_enqueue_script('hbw-script', HBW_PLUGIN_URL . 'assets/script.js', array(), '1.1.0', true);

    // Load Flatpickr from CDN for a Premium Calendar
    wp_enqueue_style('flatpickr-css', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css');
    wp_enqueue_script('flatpickr-js', 'https://cdn.jsdelivr.net/npm/flatpickr', array(), null, true);

    ob_start();
    ?>
        <style>
            .hbw-wrapper {
                --hbw-widget-primary:
                    <?php echo esc_attr($primary_color); ?>
                ;
            }

            /* v1.1.0 High-End Design */
            .hbw-wrapper {
                font-family: 'Outfit', 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif !important;
                width: 100%;
                margin: 0 auto;
                max-width: 1100px;
            }

            .hbw-form {
                background: rgba(255, 255, 255, 0.95) !important;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255, 255, 255, 0.5);
                box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15), 0 0 0 1px rgba(0, 0, 0, 0.02);
                border-radius: 1.5rem;
                padding: 1rem !important;
                display: flex !important;
                gap: 0.75rem !important;
                flex-direction: column;
                box-sizing: border-box !important;
            }

            .hbw-form * {
                box-sizing: border-box !important;
            }

            @media (min-width: 900px) {
                .hbw-form {
                    flex-direction: row !important;
                    align-items: center !important;
                    padding: 0.75rem !important;
                    border-radius: 100px !important;
                }
            }

            /* Layout: Horizontal (Desktop) */
            .hbw-layout-horizontal .hbw-form {
                max-width: 1100px;
            }

            /* Layout: Vertical (Sidebar) */
            .hbw-layout-vertical .hbw-form {
                max-width: 400px;
                flex-direction: column !important;
                border-radius: 1.5rem !important;
                margin: 0 auto;
            }

            /* Layout: Box (Card) */
            .hbw-layout-box .hbw-form {
                max-width: 500px;
                flex-direction: column !important;
                border-radius: 1.5rem !important;
                margin: 0 auto;
                padding: 2rem !important;
                background: #ffffff !important;
                border: 1px solid #e2e8f0;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            }

            .hbw-field-group {
                position: relative;
                flex: 1;
                min-width: 0;
                margin: 0 !important;
                /* Reset WP margins */
            }

            /* Input Wrap */
            .hbw-input-wrap {
                position: relative;
                background-color: #f8fafc !important;
                border-radius: 99px !important;
                transition: all 0.3s ease;
                border: 1px solid transparent;
                display: flex;
                /* Ensure height */
                align-items: center;
            }

            .hbw-input-wrap:hover {
                background-color: #fff !important;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            }

            .hbw-input-wrap:focus-within {
                background-color: #fff !important;
                border-color: var(--hbw-widget-primary) !important;
                box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.1);
            }

            .hbw-label {
                position: absolute;
                left: 3rem;
                top: 0.8rem;
                /* Adjusted top */
                font-size: 0.65rem !important;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                color: #64748b !important;
                font-weight: 700 !important;
                z-index: 10;
                pointer-events: none;
                line-height: 1;
                margin: 0 !important;
                padding: 0 !important;
            }

            .hbw-icon {
                position: absolute;
                left: 1.25rem;
                top: 50%;
                transform: translateY(-50%);
                color: var(--hbw-widget-primary) !important;
                pointer-events: none;
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 10;
                margin: 0 !important;
                padding: 0 !important;
            }

            .hbw-input {
                width: 100% !important;
                height: 3.5rem !important;
                /* Fixed height */
                padding: 1.6rem 1rem 0.4rem 3rem !important;
                background-color: transparent !important;
                border: none !important;
                font-size: 0.95rem !important;
                color: #0f172a !important;
                font-weight: 600 !important;
                outline: none !important;
                box-shadow: none !important;
                margin: 0 !important;
                border-radius: 99px !important;
            }

            /* Flex Group for Dates on Mobile */
            .hbw-flex-group {
                display: flex !important;
                gap: 0.75rem !important;
                flex: 2.5;
                margin: 0 !important;
            }

            @media (max-width: 600px) {
                .hbw-flex-group {
                    flex-direction: column !important;
                }

                .hbw-form {
                    border-radius: 1.5rem !important;
                }

                .hbw-input-wrap {
                    border-radius: 1rem !important;
                }
            }

            .hbw-btn {
                display: flex !important;
                align-items: center;
                justify-content: center;
                gap: 0.5rem;
                background: var(--hbw-widget-primary) !important;
                color: white !important;
                font-weight: 700 !important;
                padding: 0 2rem !important;
                border-radius: 99px !important;
                border: none !important;
                cursor: pointer;
                transition: all 0.3s;
                white-space: nowrap;
                font-size: 1rem !important;
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
                min-height: 3.5rem !important;
                height: 3.5rem !important;
                margin: 0 !important;
                line-height: 1 !important;
                text-transform: none !important;
            }

            .hbw-btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.15);
                filter: brightness(110%);
            }

            /* Flatpickr Customization */
            .flatpickr-calendar {
                border-radius: 1.5rem !important;
                box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25) !important;
                border: none !important;
                font-family: 'Outfit', sans-serif !important;
                padding: 1rem !important;
            }

            .flatpickr-day.selected {
                background: var(--hbw-widget-primary) !important;
                border-color: var(--hbw-widget-primary) !important;
            }
        </style>

        <div class="hbw-wrapper hbw-layout-<?php echo esc_attr($layout); ?>">
            <form method="GET" action="<?php echo esc_url($target_url . '/search'); ?>" class="hbw-form" <?php if ($is_preview)
                     echo 'onsubmit="event.preventDefault();"'; ?>>
                <?php
                // Context: Hotel ID from Shortcode [hotel_booking_search hotel_id="123"]
                $hotel_id = isset($atts['hotel_id']) ? $atts['hotel_id'] : $default_hotel_id;
                if (!empty($hotel_id)) {
                    echo '<input type="hidden" name="hotelId" value="' . esc_attr($hotel_id) . '">';
                }
                ?>

                <!-- Dates Group -->
                <div class="hbw-flex-group">
                    <div class="hbw-field-group hbw-input-wrap">
                        <span class="hbw-label">Check-in</span>
                        <div class="hbw-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none"
                                stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                <line x1="16" y1="2" x2="16" y2="6"></line>
                                <line x1="8" y1="2" x2="8" y2="6"></line>
                                <line x1="3" y1="10" x2="21" y2="10"></line>
                            </svg>
                        </div>
                        <input type="text" name="checkIn" id="hbw-checkin" class="hbw-input hbw-date" placeholder="Add Date"
                            required>
                    </div>
                    <div class="hbw-field-group hbw-input-wrap">
                        <span class="hbw-label">Check-out</span>
                        <div class="hbw-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none"
                                stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                <line x1="16" y1="2" x2="16" y2="6"></line>
                                <line x1="8" y1="2" x2="8" y2="6"></line>
                                <line x1="3" y1="10" x2="21" y2="10"></line>
                            </svg>
                        </div>
                        <input type="text" name="checkOut" id="hbw-checkout" class="hbw-input hbw-date"
                            placeholder="Add Date" required>
                    </div>
                </div>

                <!-- Guests Group -->
                <div class="hbw-flex-group" style="flex: 2;">
                    <div class="hbw-field-group hbw-input-wrap">
                        <span class="hbw-label">Adults</span>
                        <div class="hbw-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none"
                                stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                <circle cx="12" cy="7" r="4"></circle>
                            </svg>
                        </div>
                        <input type="number" name="adults" class="hbw-input" min="1" value="2" placeholder="2">
                    </div>
                    <div class="hbw-field-group hbw-input-wrap">
                        <span class="hbw-label">Children</span>
                        <div class="hbw-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none"
                                stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M15.5 21a2 2 0 0 1-3.6 0"></path>
                                <path d="M16.5 10a4 4 0 0 0-9 0"></path>
                                <circle cx="12" cy="7" r="3"></circle>
                            </svg>
                        </div>
                        <input type="number" name="children" class="hbw-input" min="0" value="0" placeholder="0">
                    </div>
                </div>

                <!-- Search Button -->
                <button type="submit" class="hbw-btn">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                    <span>Search</span>
                </button>
            </form>
        </div>

        <script>
            function initHBWFlatpickr() {
                if (typeof flatpickr !== 'undefined') {
                    const today = new Date();
                    const tomorrow = new Date();
                    tomorrow.setDate(today.getDate() + 1);

                    const checkInElements = document.querySelectorAll("#hbw-checkin");
                    const checkOutElements = document.querySelectorAll("#hbw-checkout");

                    checkInElements.forEach((el, index) => {
                        const checkOutEl = checkOutElements[index];
                        if (checkOutEl) {
                            const checkOutPicker = flatpickr(checkOutEl, {
                                minDate: tomorrow,
                                defaultDate: tomorrow,
                                dateFormat: "Y-m-d",
                                altInput: true,
                                altFormat: "D, M j"
                            });

                            flatpickr(el, {
                                minDate: "today",
                                defaultDate: today,
                                dateFormat: "Y-m-d",
                                altInput: true,
                                altFormat: "D, M j",
                                onChange: function (selectedDates) {
                                    if (selectedDates[0]) {
                                        const minOutDate = new Date(selectedDates[0]);
                                        minOutDate.setDate(minOutDate.getDate() + 1);
                                        checkOutPicker.set('minDate', minOutDate);
                                        checkOutPicker.setDate(minOutDate);
                                    }
                                }
                            });
                        }
                    });
                }
            }

            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', initHBWFlatpickr);
            } else {
                initHBWFlatpickr();
            }
        </script>
        <?php

        return ob_get_clean();
}
add_shortcode('hotel_booking_search', 'hbw_render_search_widget');
