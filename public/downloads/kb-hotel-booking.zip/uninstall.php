<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @package   KB_Hotel_Booking
 */

// If uninstall not called from WordPress, then exit.
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete the option from the database
delete_option('hbw_settings');
